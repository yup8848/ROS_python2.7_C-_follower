﻿def add(a,b):
    return a+b

def get_name(first):
    return 
